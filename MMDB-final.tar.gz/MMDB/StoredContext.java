
public class StoredContext {
	public String[] fileNames;
	public StoredContext(String[] fileNames)
	{
		this.fileNames = fileNames;
	}
}
